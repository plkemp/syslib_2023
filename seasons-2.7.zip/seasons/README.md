# Seasons
A colorful theme with a configuration option to switch style sheets for a particular season. For version 1.2 and above, Seasons offers the style sheets of earlier themes, Spring, Summer, Fall, Winter. 

Seasons is Copyright © 2018-present Corporation for Digital Scholarship, Vienna, Virginia, USA http://digitalscholar.org

The Corporation for Digital Scholarship distributes the Omeka source code under the GNU General Public License, version 3 (GPLv3). See the LICENSE file for the full text.

The Omeka name is a registered trademark of the Corporation for Digital Scholarship.

Third-party copyright in this distribution is noted where applicable.

All rights not expressly granted are reserved.
